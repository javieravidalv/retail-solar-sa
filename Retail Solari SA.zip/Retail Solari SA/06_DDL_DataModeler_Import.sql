-- =============================================================================
-- SCRIPT DDL — RETAIL SOLARI S.A.
-- Propósito : Importación en Oracle SQL Developer Data Modeler
--             (File → Import → DDL File)
-- Contiene  : Solo CREATE TABLE con PRIMARY KEY, FOREIGN KEY, UNIQUE y CHECK.
--             Sin triggers, secuencias, índices, datos de prueba ni PL/SQL.
-- Versión   : 1.0
-- =============================================================================
-- ORDEN DE CREACIÓN (respeta dependencias de claves foráneas):
--   1. REGION              9. SUCURSAL
--   2. COMUNA             10. PRODUCTO
--   3. CATEGORIA          11. PRODUCTO_SUCURSAL
--   4. MARCA              12. PRODUCTO_PROVEEDOR
--   5. MODELO             13. CLIENTE
--   6. PROVEEDOR          14. BOLETA_VENTA
--   7. PROVEEDOR_EMPRESA  15. DETALLE_BOLETA
--   8. PROVEEDOR_PERSONA
-- =============================================================================


-- -----------------------------------------------------------------------------
-- 1. REGION
-- -----------------------------------------------------------------------------
CREATE TABLE REGION (
    cod_region      CHAR(2)         NOT NULL,
    nombre_region   VARCHAR2(80)    NOT NULL,
    CONSTRAINT PK_REGION
        PRIMARY KEY (cod_region)
);


-- -----------------------------------------------------------------------------
-- 2. COMUNA
-- -----------------------------------------------------------------------------
CREATE TABLE COMUNA (
    cod_comuna      CHAR(5)         NOT NULL,
    nombre_comuna   VARCHAR2(80)    NOT NULL,
    cod_region      CHAR(2)         NOT NULL,
    CONSTRAINT PK_COMUNA
        PRIMARY KEY (cod_comuna),
    CONSTRAINT FK_COMUNA_REGION
        FOREIGN KEY (cod_region)
        REFERENCES REGION (cod_region)
);


-- -----------------------------------------------------------------------------
-- 3. CATEGORIA
-- -----------------------------------------------------------------------------
CREATE TABLE CATEGORIA (
    cod_categoria       NUMBER(4)       NOT NULL,
    nombre_categoria    VARCHAR2(60)    NOT NULL,
    descripcion         VARCHAR2(200)   NULL,
    tiene_vencimiento   CHAR(1)         DEFAULT 'S' NOT NULL,
    CONSTRAINT PK_CATEGORIA
        PRIMARY KEY (cod_categoria),
    CONSTRAINT UQ_CATEGORIA_NOMBRE
        UNIQUE (nombre_categoria),
    CONSTRAINT CK_CATEGORIA_VENCE
        CHECK (tiene_vencimiento IN ('S', 'N'))
);


-- -----------------------------------------------------------------------------
-- 4. MARCA
-- -----------------------------------------------------------------------------
CREATE TABLE MARCA (
    cod_marca       NUMBER(4)       NOT NULL,
    nombre_marca    VARCHAR2(80)    NOT NULL,
    CONSTRAINT PK_MARCA
        PRIMARY KEY (cod_marca),
    CONSTRAINT UQ_MARCA_NOMBRE
        UNIQUE (nombre_marca)
);


-- -----------------------------------------------------------------------------
-- 5. MODELO  (entidad débil de MARCA — PK compuesta)
-- -----------------------------------------------------------------------------
CREATE TABLE MODELO (
    cod_modelo          NUMBER(6)       NOT NULL,
    cod_marca           NUMBER(4)       NOT NULL,
    descripcion_modelo  VARCHAR2(150)   NOT NULL,
    cod_categoria       NUMBER(4)       NOT NULL,
    CONSTRAINT PK_MODELO
        PRIMARY KEY (cod_modelo, cod_marca),
    CONSTRAINT FK_MODELO_MARCA
        FOREIGN KEY (cod_marca)
        REFERENCES MARCA (cod_marca),
    CONSTRAINT FK_MODELO_CATEGORIA
        FOREIGN KEY (cod_categoria)
        REFERENCES CATEGORIA (cod_categoria)
);


-- -----------------------------------------------------------------------------
-- 6. PROVEEDOR  (supertipo — discriminador: tipo_proveedor)
-- -----------------------------------------------------------------------------
CREATE TABLE PROVEEDOR (
    rut_proveedor   NUMBER(8)       NOT NULL,
    dv              CHAR(1)         NOT NULL,
    tipo_proveedor  CHAR(1)         NOT NULL,
    fono            VARCHAR2(15)    NOT NULL,
    email           VARCHAR2(100)   NOT NULL,
    calle_direccion VARCHAR2(100)   NOT NULL,
    num_calle       VARCHAR2(10)    NOT NULL,
    cod_postal      VARCHAR2(7)     NULL,
    cod_comuna      CHAR(5)         NOT NULL,
    CONSTRAINT PK_PROVEEDOR
        PRIMARY KEY (rut_proveedor),
    CONSTRAINT UQ_PROVEEDOR_EMAIL
        UNIQUE (email),
    CONSTRAINT FK_PROVEEDOR_COMUNA
        FOREIGN KEY (cod_comuna)
        REFERENCES COMUNA (cod_comuna),
    CONSTRAINT CK_PROVEEDOR_DV
        CHECK (dv IN ('0','1','2','3','4','5','6','7','8','9','K')),
    CONSTRAINT CK_PROVEEDOR_TIPO
        CHECK (tipo_proveedor IN ('E','P')),
    CONSTRAINT CK_PROVEEDOR_RUT
        CHECK (rut_proveedor BETWEEN 1 AND 99999999)
);


-- -----------------------------------------------------------------------------
-- 7. PROVEEDOR_EMPRESA  (subtipo — tipo_proveedor = 'E')
-- -----------------------------------------------------------------------------
CREATE TABLE PROVEEDOR_EMPRESA (
    rut_proveedor   NUMBER(8)       NOT NULL,
    razon_social    VARCHAR2(150)   NOT NULL,
    nombre_fantasia VARCHAR2(100)   NULL,
    website         VARCHAR2(200)   NULL,
    CONSTRAINT PK_PROV_EMPRESA
        PRIMARY KEY (rut_proveedor),
    CONSTRAINT FK_PROV_EMPRESA_PROV
        FOREIGN KEY (rut_proveedor)
        REFERENCES PROVEEDOR (rut_proveedor)
);


-- -----------------------------------------------------------------------------
-- 8. PROVEEDOR_PERSONA  (subtipo — tipo_proveedor = 'P')
-- -----------------------------------------------------------------------------
CREATE TABLE PROVEEDOR_PERSONA (
    rut_proveedor       NUMBER(8)       NOT NULL,
    nombres             VARCHAR2(80)    NOT NULL,
    apellido_paterno    VARCHAR2(50)    NOT NULL,
    apellido_materno    VARCHAR2(50)    NULL,
    CONSTRAINT PK_PROV_PERSONA
        PRIMARY KEY (rut_proveedor),
    CONSTRAINT FK_PROV_PERSONA_PROV
        FOREIGN KEY (rut_proveedor)
        REFERENCES PROVEEDOR (rut_proveedor)
);


-- -----------------------------------------------------------------------------
-- 9. SUCURSAL
-- -----------------------------------------------------------------------------
CREATE TABLE SUCURSAL (
    sigla_sucursal  CHAR(6)         NOT NULL,
    nombre_sucursal VARCHAR2(100)   NOT NULL,
    cod_comuna      CHAR(5)         NOT NULL,
    CONSTRAINT PK_SUCURSAL
        PRIMARY KEY (sigla_sucursal),
    CONSTRAINT FK_SUCURSAL_COMUNA
        FOREIGN KEY (cod_comuna)
        REFERENCES COMUNA (cod_comuna)
);


-- -----------------------------------------------------------------------------
-- 10. PRODUCTO
-- -----------------------------------------------------------------------------
CREATE TABLE PRODUCTO (
    id_producto         NUMBER(6)       NOT NULL,
    nombre_producto     VARCHAR2(120)   NOT NULL,
    descripcion         VARCHAR2(300)   NULL,
    fecha_vencimiento   DATE            NULL,
    precio_lista        NUMBER(10,2)    NOT NULL,
    cod_modelo          NUMBER(6)       NOT NULL,
    cod_marca           NUMBER(4)       NOT NULL,
    CONSTRAINT PK_PRODUCTO
        PRIMARY KEY (id_producto),
    CONSTRAINT FK_PRODUCTO_MODELO
        FOREIGN KEY (cod_modelo, cod_marca)
        REFERENCES MODELO (cod_modelo, cod_marca),
    CONSTRAINT CK_PRODUCTO_PRECIO
        CHECK (precio_lista > 0)
);


-- -----------------------------------------------------------------------------
-- 11. PRODUCTO_SUCURSAL  (asociación N:M — PK compuesta)
-- -----------------------------------------------------------------------------
CREATE TABLE PRODUCTO_SUCURSAL (
    id_producto         NUMBER(6)       NOT NULL,
    sigla_sucursal      CHAR(6)         NOT NULL,
    stock_disponible    NUMBER(8)       DEFAULT 0 NOT NULL,
    precio_sucursal     NUMBER(10,2)    NULL,
    CONSTRAINT PK_PROD_SUCURSAL
        PRIMARY KEY (id_producto, sigla_sucursal),
    CONSTRAINT FK_PRODSUC_PRODUCTO
        FOREIGN KEY (id_producto)
        REFERENCES PRODUCTO (id_producto),
    CONSTRAINT FK_PRODSUC_SUCURSAL
        FOREIGN KEY (sigla_sucursal)
        REFERENCES SUCURSAL (sigla_sucursal),
    CONSTRAINT CK_PRODSUC_STOCK
        CHECK (stock_disponible >= 0),
    CONSTRAINT CK_PRODSUC_PRECIO
        CHECK (precio_sucursal IS NULL OR precio_sucursal > 0)
);


-- -----------------------------------------------------------------------------
-- 12. PRODUCTO_PROVEEDOR  (asociación N:M — PK compuesta)
-- -----------------------------------------------------------------------------
CREATE TABLE PRODUCTO_PROVEEDOR (
    id_producto     NUMBER(6)       NOT NULL,
    rut_proveedor   NUMBER(8)       NOT NULL,
    fecha_inicio    DATE            NOT NULL,
    precio_costo    NUMBER(10,2)    NULL,
    CONSTRAINT PK_PROD_PROV
        PRIMARY KEY (id_producto, rut_proveedor),
    CONSTRAINT FK_PRODPROV_PRODUCTO
        FOREIGN KEY (id_producto)
        REFERENCES PRODUCTO (id_producto),
    CONSTRAINT FK_PRODPROV_PROVEEDOR
        FOREIGN KEY (rut_proveedor)
        REFERENCES PROVEEDOR (rut_proveedor),
    CONSTRAINT CK_PRODPROV_COSTO
        CHECK (precio_costo IS NULL OR precio_costo > 0)
);


-- -----------------------------------------------------------------------------
-- 13. CLIENTE
-- -----------------------------------------------------------------------------
CREATE TABLE CLIENTE (
    id_cliente          NUMBER(8)       NOT NULL,
    nombres             VARCHAR2(80)    NOT NULL,
    apellido_paterno    VARCHAR2(50)    NOT NULL,
    apellido_materno    VARCHAR2(50)    NULL,
    telefono            VARCHAR2(15)    NOT NULL,
    cod_comuna          CHAR(5)         NOT NULL,
    CONSTRAINT PK_CLIENTE
        PRIMARY KEY (id_cliente),
    CONSTRAINT FK_CLIENTE_COMUNA
        FOREIGN KEY (cod_comuna)
        REFERENCES COMUNA (cod_comuna)
);


-- -----------------------------------------------------------------------------
-- 14. BOLETA_VENTA
-- -----------------------------------------------------------------------------
CREATE TABLE BOLETA_VENTA (
    nro_boleta      NUMBER(8)       NOT NULL,
    fecha_venta     DATE            NOT NULL,
    monto_total     NUMBER(12,2)    NOT NULL,
    id_cliente      NUMBER(8)       NOT NULL,
    sigla_sucursal  CHAR(6)         NOT NULL,
    CONSTRAINT PK_BOLETA
        PRIMARY KEY (nro_boleta),
    CONSTRAINT FK_BOLETA_CLIENTE
        FOREIGN KEY (id_cliente)
        REFERENCES CLIENTE (id_cliente),
    CONSTRAINT FK_BOLETA_SUCURSAL
        FOREIGN KEY (sigla_sucursal)
        REFERENCES SUCURSAL (sigla_sucursal),
    CONSTRAINT CK_BOLETA_TOTAL
        CHECK (monto_total > 0)
);


-- -----------------------------------------------------------------------------
-- 15. DETALLE_BOLETA  (entidad débil de BOLETA_VENTA — PK compuesta)
-- -----------------------------------------------------------------------------
CREATE TABLE DETALLE_BOLETA (
    nro_boleta          NUMBER(8)       NOT NULL,
    id_producto         NUMBER(6)       NOT NULL,
    cantidad            NUMBER(5)       NOT NULL,
    precio_unitario     NUMBER(10,2)    NOT NULL,
    subtotal            NUMBER(12,2)    NOT NULL,
    CONSTRAINT PK_DETALLE
        PRIMARY KEY (nro_boleta, id_producto),
    CONSTRAINT FK_DETALLE_BOLETA
        FOREIGN KEY (nro_boleta)
        REFERENCES BOLETA_VENTA (nro_boleta),
    CONSTRAINT FK_DETALLE_PRODUCTO
        FOREIGN KEY (id_producto)
        REFERENCES PRODUCTO (id_producto),
    CONSTRAINT CK_DETALLE_CANT
        CHECK (cantidad >= 1),
    CONSTRAINT CK_DETALLE_PRECIO
        CHECK (precio_unitario > 0),
    CONSTRAINT CK_DETALLE_SUBTOTAL
        CHECK (subtotal > 0)
);

-- =============================================================================
-- FIN DEL SCRIPT — 15 tablas listas para importar en SQL Developer Data Modeler
-- =============================================================================
